<div class="flex mx-1 mb-1">
<code>
<?php echo htmlspecialchars($message) ?>
</code>
</div>